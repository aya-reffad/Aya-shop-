document.getElementById("orderForm").addEventListener("submit", function(e){
  e.preventDefault();
  const store=document.getElementById("store").value;
  const type=document.getElementById("type").value;
  const wilaya=document.getElementById("wilaya").value;
  const link=document.getElementById("link").value;
  const notes=document.getElementById("notes").value;
  document.getElementById("result").textContent =
    "تم تسجيل تفاصيل الطلب على الصفحة. الدفع مسبقًا عبر BaridiMob، وسيتم تأكيد الطلب بعد التواصل معك.";
});
